import sys
import zipfile
import os
import io
import pandas as pd
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTextEdit, QPushButton, QLabel,
    QHBoxLayout, QSizePolicy, QFileDialog, QMessageBox, QTableWidget, QTableWidgetItem
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer, QUrl
from PyQt5.QtGui import QFont, QKeyEvent, QTextOption, QPixmap, QTextCursor, QTextImageFormat, QImage

# ✅ נוספה קריאה לסוכן בזמן טעינה

from Ai_Agents.Agent_HVT.agent_runner import ask_agent
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas

def summarize_failures(data):
    if data is None:
        return "No data loaded. Please load a file with CSV(s) first."

    summary = []
    required_columns = {'DUT_SN', 'Sys_Type', 'Freq', 'Verdict', 'Test_Name'}
    if not required_columns.issubset(data.columns):
        return "Missing required columns in data."

    grouped = data[data['Verdict'] != 1].groupby(['DUT_SN', 'Sys_Type'])

    for (dut, system), group in grouped:
        tests = group['Test_Name'].unique().tolist()
        freqs = group['Freq'].unique().tolist()
        date = group['source_file'].iloc[0] if 'source_file' in group else 'unknown'
        summary.append({
            'Unit': dut,
            'System': system,
            'Failed_Tests': tests,
            'Failed_Freqs': freqs,
            'Source_File': date
        })

    if not summary:
        return "No failures found in the dataset."

    df_summary = pd.DataFrame(summary)
    return df_summary   # <------ כאן לשים במקום return df_summary.to_markdown(index=False)


class AgentThread(QThread):
    result_ready = pyqtSignal(object)
    error_occurred = pyqtSignal(str)

    def __init__(self, question, data=None):
        super().__init__()
        self.question = question
        self.data = data

    def run(self):
        try:
            if "summarize failures" in self.question.lower():
                answer = summarize_failures(self.data)
            else:
                answer = ask_agent(self.question, self.data)
            self.result_ready.emit(answer)
        except Exception as e:
            self.error_occurred.emit(str(e))

class AgentChatGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Agent Chat")
        self.resize(1000, 720)
        self.loaded_data = None
        self.init_ui()

    def init_ui(self):
        self.setStyleSheet("background-color: #202020; color: #ffffff;")

        layout = QVBoxLayout()

        title = QLabel("🤖 Agent - HVT Data")
        title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        title.setStyleSheet("color: #ffffff; margin-bottom: 12px;")
        layout.addWidget(title)

        self.chat_display = QTextEdit()
        self.chat_display.setReadOnly(True)
        self.chat_display.setFont(QFont("Segoe UI", 10))
        self.chat_display.setStyleSheet("background-color: #282828; color: #ffffff; padding: 12px; border-radius: 8px; border: 1px solid #333;")
        layout.addWidget(self.chat_display)

        self.table_widget = QTableWidget()
        self.table_widget.setStyleSheet("background-color: #282828; color: #ffffff; border-radius: 8px; border: 1px solid #333;")
        self.table_widget.setVisible(False)
        layout.addWidget(self.table_widget)

        input_layout = QHBoxLayout()

        self.input_field = QTextEdit()
        self.input_field.setPlaceholderText("Type your question here...")
        self.input_field.setFont(QFont("Segoe UI", 10))
        self.input_field.setStyleSheet("background-color: #2d2d2d; color: white; padding: 8px; border-radius: 6px; border: 1px solid #666;")
        self.input_field.setFixedHeight(80)
        self.input_field.installEventFilter(self)
        self.input_field.setLayoutDirection(Qt.LeftToRight)
        self.input_field.document().setDefaultTextOption(QTextOption(Qt.AlignLeft))

        input_button_layout = QVBoxLayout()

        self.send_button = QPushButton("Send")
        self.send_button.setFont(QFont("Segoe UI", 10))
        self.send_button.setStyleSheet("background-color: #26c6da; color: white; padding: 8px 16px; border-radius: 5px;")
        self.send_button.clicked.connect(self.handle_query)

        self.clear_button = QPushButton("Clear")
        self.clear_button.setFont(QFont("Segoe UI", 10))
        self.clear_button.setStyleSheet("background-color: #666; color: white; padding: 8px 16px; border-radius: 5px;")
        self.clear_button.clicked.connect(self.chat_display.clear)

        button_row_layout = QHBoxLayout()
        button_row_layout.addWidget(self.send_button)
        button_row_layout.addWidget(self.clear_button)

        self.load_file_button = QPushButton("Add Files")
        self.load_file_button.setFont(QFont("Segoe UI", 10))
        self.load_file_button.setStyleSheet("background-color: #8bc34a; color: white; padding: 8px 16px; border-radius: 5px;")
        self.load_file_button.setFixedSize(172, 36)
        self.load_file_button.clicked.connect(self.load_data_dialog)

        input_button_layout.addLayout(button_row_layout)
        input_button_layout.addWidget(self.load_file_button)
        input_layout.addWidget(self.input_field)
        input_layout.addLayout(input_button_layout)

        layout.addLayout(input_layout)

        self.status_label = QLabel("Ready")
        self.status_label.setStyleSheet("color: #aaaaaa; padding: 4px;")
        layout.addWidget(self.status_label)

        self.setLayout(layout)

    def handle_query(self):
        question = self.input_field.toPlainText().strip()
        if not question:
            return

        self.chat_display.append(f"<b>You:</b> {question}<br>")
        self.status_label.setText("Thinking...")
        self.input_field.clear()

        self.thread = AgentThread(question, data=self.loaded_data)
        self.thread.result_ready.connect(self.display_agent_response)
        self.thread.error_occurred.connect(self.display_error)
        self.thread.start()

    def display_agent_response(self, result):
        # First, always hide the table
        self.table_widget.setVisible(False)
        # Try: if the answer is a pandas DataFrame, show as table
        if isinstance(result, pd.DataFrame):
            self.show_table(result)
        elif isinstance(result, list) and all(isinstance(row, dict) for row in result):
            # if result is a list of dicts (typical for preview rows) - show as table
            df = pd.DataFrame(result)
            self.show_table(df)
        elif isinstance(result, Figure):
            self.insert_chart_into_chat(result)
        else:
            self.chat_display.append(f"<b>Agent:</b> {result}<br>")
        self.status_label.setText("Ready")

    def show_table(self, df):
        self.table_widget.setVisible(True)
        self.table_widget.setRowCount(len(df))
        self.table_widget.setColumnCount(len(df.columns))
        self.table_widget.setHorizontalHeaderLabels(df.columns.astype(str))
        for i, row in df.iterrows():
            for j, col in enumerate(df.columns):
                item = QTableWidgetItem(str(row[col]))
                self.table_widget.setItem(i, j, item)
        self.table_widget.resizeColumnsToContents()
        self.table_widget.resizeRowsToContents()

    def display_error(self, error):
        self.chat_display.append(f"<b>⚠️ Error:</b> {error}<br>")
        self.status_label.setText("Ready")

    def insert_chart_into_chat(self, fig):
        canvas = FigureCanvas(fig)
        buffer = io.BytesIO()
        canvas.print_png(buffer)
        buffer.seek(0)

        image = QImage()
        image.loadFromData(buffer.read(), format='PNG')

        cursor = self.chat_display.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.chat_display.append("<b>Agent:</b> מציג גרף:<br>")
        cursor.insertImage(image)
        self.chat_display.setTextCursor(cursor)
        self.chat_display.ensureCursorVisible()

    def load_data_dialog(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select ZIP or CSV File", "", "ZIP or CSV Files (*.zip *.csv)")

        if not path:
            QMessageBox.information(self, "Info", "No file selected.")
            return

        try:
            self.chat_display.append(f"<b>You:</b> טען את הקובץ {path}<br>")
            self.status_label.setText("Loading...")

            answer = ask_agent(f"טען את הקובץ {path}")
            self.chat_display.append(f"<b>Agent:</b> {answer}<br>")
            self.status_label.setText("Ready")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred while loading file:\n{str(e)}")

    def eventFilter(self, source, event):
        if source == self.input_field and event.type() == event.KeyPress:
            if event.key() == Qt.Key_Return and not (event.modifiers() & Qt.ShiftModifier):
                self.handle_query()
                return True
        return super().eventFilter(source, event)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = AgentChatGUI()
    window.show()
    sys.exit(app.exec_())
